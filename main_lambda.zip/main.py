# main.py
"""
Entry point for the ETL process.
"""

from etl_pipeline import run_etl

if __name__ == "__main__":
    CSV_PATH = "employee_data.csv"  # Path to your CSV file
    TABLE_NAME = "employee_data"    # MySQL table name

    # Start the ETL process
    run_etl(CSV_PATH, TABLE_NAME)
