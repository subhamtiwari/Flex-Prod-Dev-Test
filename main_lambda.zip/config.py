# config.py
# Configuration file for AWS and MySQL

# AWS Configuration
AWS_ACCESS_KEY = "AKIATCKAOHYHDIKYMTZF"  # AWS Access Key
AWS_SECRET_KEY = "8jGwqSntSR0VGfby+wVmBx+oNg+dZFXYkazbhphE"  # AWS Secret Key
AWS_REGION = "us-east-1"  # AWS region for your S3 bucket

# MySQL Configuration
DATABASE_CONFIG = {
    "host": "minted-owl-instance-1.c1eqcg2a2i4q.us-east-1.rds.amazonaws.com",  # RDS endpoint
    "user": "admin",  # RDS username
    "password": "Qwerty6118$",  # RDS password
    "database": "employee",  # Database name
    "port": 3306  # Default MySQL port
}

# S3 Bucket Name
BUCKET_NAME = "etl-transformed-data-bucket"  # S3 bucket name
