# etl_pipeline.py
"""
ETL pipeline for creating a MySQL table, inserting data from a CSV file, 
and uploading transformed data to S3.
"""

import pandas as pd
import pymysql
import boto3
from botocore.exceptions import ClientError
from config import AWS_ACCESS_KEY, AWS_SECRET_KEY, AWS_REGION, DATABASE_CONFIG, BUCKET_NAME

# S3 Operations
def create_s3_bucket(bucket_name):
    print(f"Ensuring S3 bucket exists: {bucket_name}")
    session = boto3.Session(aws_access_key_id=AWS_ACCESS_KEY, aws_secret_access_key=AWS_SECRET_KEY, region_name=AWS_REGION)
    s3 = session.client('s3')
    try:
        s3.create_bucket(Bucket=bucket_name, CreateBucketConfiguration={"LocationConstraint": AWS_REGION})
        print(f"S3 bucket '{bucket_name}' is ready.")
    except ClientError as e:
        if e.response['Error']['Code'] == 'BucketAlreadyOwnedByYou':
            print(f"S3 bucket '{bucket_name}' already exists.")
        else:
            print(f"Error creating bucket: {e}")
            raise

def upload_to_s3(file_path, bucket_name, object_name):
    print(f"Uploading {file_path} to S3 bucket '{bucket_name}' as {object_name}.")
    session = boto3.Session(aws_access_key_id=AWS_ACCESS_KEY, aws_secret_access_key=AWS_SECRET_KEY)
    s3 = session.resource('s3')
    try:
        s3.Bucket(bucket_name).upload_file(file_path, object_name)
        print("File uploaded successfully.")
    except Exception as e:
        print(f"Error: {e}")

# MySQL Operations
class DatabaseConnection:
    def __init__(self, config):
        self.config = config
        self.connection = None

    def connect(self):
        self.connection = pymysql.connect(**self.config)
        print("Database connection established.")

    def execute_query(self, query, params=None):
        with self.connection.cursor() as cursor:
            cursor.execute(query, params or ())
            self.connection.commit()
            print(f"Query executed: {query}")

    def close(self):
        if self.connection:
            self.connection.close()
            print("Database connection closed.")

# Create and Populate MySQL Table
def create_and_populate_table(csv_path, table_name):
    print(f"Reading CSV file: {csv_path}")
    data = pd.read_csv(csv_path)

    db = DatabaseConnection(DATABASE_CONFIG)
    try:
        db.connect()

        # Create Table
        create_table_query = f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            EMPLOYEE_ID INT,
            FIRST_NAME VARCHAR(50),
            LAST_NAME VARCHAR(50),
            EMAIL VARCHAR(50),
            PHONE_NUMBER VARCHAR(20),
            HIRE_DATE DATE,
            JOB_ID VARCHAR(20),
            SALARY DECIMAL(10, 2),
            COMMISSION_PCT VARCHAR(10),
            MANAGER_ID INT,
            DEPARTMENT_ID INT
        );
        """
        db.execute_query(create_table_query)

        # Insert Data
        for _, row in data.iterrows():
            row = row.fillna(None)  # Replace NaN with None (interpreted as NULL in MySQL)
            placeholders = ", ".join(["%s"] * len(row.values))  # Generate placeholders
            insert_query = f"INSERT INTO {table_name} VALUES ({placeholders})"
            db.execute_query(insert_query, tuple(row.values))  # Pass row values as a tuple
        print(f"Data inserted into '{table_name}' table.")
    finally:
        db.close()

    return data

# ETL Orchestrator
def run_etl(csv_path, table_name):
    print("Starting ETL process.")

    # Step 1: Create and Populate MySQL Table
    data = create_and_populate_table(csv_path, table_name)

    # Step 2: Save Processed Data Locally
    processed_file_path = "processed_data.csv"
    data.to_csv(processed_file_path, index=False)
    print("Processed data saved locally.")

    # Step 3: Upload Processed Data to S3
    create_s3_bucket(BUCKET_NAME)
    upload_to_s3(processed_file_path, BUCKET_NAME, "processed_data.csv")

    print("ETL process completed.")
